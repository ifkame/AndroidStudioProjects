//IE3A18 藤村伊織

package ie3a_2190402.firebase08

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity : AppCompatActivity() {
    // フィールド用の変数（カウント数）を定義する
    var name :String? = null
    var pas :String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 事前に DB へ、名前：user 値：""を追加しておくことで、
        val userdb = FirebaseDatabase.getInstance().getReference("user")
        // TextView を id:count_view で定義しておいた場合の例（id の取得）
        val username = findViewById<EditText>(R.id.username_edit)
        val password = findViewById<EditText>(R.id.password_edit)

        // データベースの値が変更された場合に呼ばれるイベント処理
        userdb.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // データベースの値を取得する（読み込み）
                /*name = snapshot.value as String
                pas = snapshot.value as String
                username.setText(name.toString())
                password.setText(pas.toString())*/
            }
            override fun onCancelled(error: DatabaseError) {
                //ここにエラーがあった場合の処理を記述する
                Toast.makeText(applicationContext,
                    "onCancelled が呼ばれました\n" + error.details, Toast.LENGTH_LONG).show()
            }
        })

        // データベースの参照を取得する
        //val ref = userdb.getRef()

        // Button を id:button で定義しておいた場合の例（id の取得）
        val buttonWrite = findViewById<Button>(R.id.button)
        // ボタンが押された場合の処理
        buttonWrite.setOnClickListener {
            // 名前：user の子要素に、名前：username と値：password の組を追加することができる。
            userdb.child(username.text.toString()).setValue(password.text.toString())
        }
    }
}